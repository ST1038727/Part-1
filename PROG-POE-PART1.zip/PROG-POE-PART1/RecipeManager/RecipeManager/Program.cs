﻿using System;
using RecipeManager;

namespace RecipeManager
{
    class Recipe
    {
        //Fields
        public string[] ingredients;
        public string[] steps;
        public int quantity;

        //Constructor
        public Recipe(int numIngredients, int numSteps)
        {
            ingredients = new string[numIngredients];
            steps = new string[numSteps];
        }

        //Method to set ingredient details
        public void SetIngredient(int index, string name, double quantity, string unit)
        {
            ingredients[index] = $"{quantity} {unit} of {name}";
        }

        //Method to set step details
        public void SetStep(int index, string description)
        {
            steps[index] = description;
        }

        //Method to display the recipe
        public void DisplayRecipe()
        {
            Console.WriteLine("Recipe:");
            Console.WriteLine("Ingredients:");
            foreach (var ingredient in ingredients)
            {
                Console.WriteLine("- " + ingredient);
            }
            Console.WriteLine("Steps:");
            for (int i = 0; i < steps.Length; i++)
            {
                Console.WriteLine($"{i + 1}. {steps[i]}");
            }
        }

        //Method to scale the recipe
        public void ScaleRecipe(double factor)
        {
            for (int i = 0; i <ingredients.Length; i++)
            {
                //Parse the ingredient quantity
                string[] parts = ingredients[i].Split(' ');
                double quantity = double.Parse(parts[0]);
                //Scale the quantity
                quantity *= factor;
                //Update the ingredient string
                ingredients[i] = $"{quantity} {parts[1]} of {string.Join(" ", parts, 3, parts.Length - 3)}";
            }
        }

        //Method to reset ingredient quantities to original values
        public Recipe(int initialQuantity)
        {
            quantity = initialQuantity;
        }
        public void ResetQuantities()
        {
            quantity = 0;
            Console.WriteLine("Quantity reset to 0.");
        }

        public int GetQuantity()
        {
            return quantity;
        }

        // Method to clear all recipe data 
        public void ClearRecipe()
        {
            
        }
    }
}

     class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Welcome to Recipe Manager!");

        //get user input for recipe details
        Console.Write("Enter the number of ingredients: ");
        int numIngredients = int.Parse(Console.ReadLine());

        Console.Write("Enter the number of steps: ");
        int numSteps = int.Parse(Console.ReadLine());

        //Create a new recipe
        Recipe recipe = new Recipe(numIngredients, numSteps);

        //Get ingredient details
        for (int i = 0; i < numIngredients; i++)
        {
            Console.WriteLine($"Enter details for ingredient {i + 1}:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            Console.Write("Quantity: ");
            double quantity = double.Parse(Console.ReadLine());
            Console.Write("Unit: ");
            string unit = Console.ReadLine();
            recipe.SetIngredient(i, name, quantity, unit);
        }

        //Get step details
        for (int i = 0; i < numSteps; i++)
        {
            Console.WriteLine($"Enter details for step {i + 1}:");
            Console.Write("Description: ");
            string description = Console.ReadLine();
            recipe.SetStep(i, description);
        }

        //Display the recipe
        recipe.DisplayRecipe();

        // TODO: Implement scaling, and clearing options
        //Resetting the quantity
        Recipe manager = new Recipe(10);
        Console.WriteLine("Current quantity: " + manager.GetQuantity());

        manager.ResetQuantities();
        Console.WriteLine("Current quantity after rest: " + manager.GetQuantity());

        Console.WriteLine("Thank you for using Recipe Manager!");
        }
    }

